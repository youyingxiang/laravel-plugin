@extends('plugin3::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>
        This view is loaded from plugin: {!! config('plugin3.name') !!}
    </p>
@endsection
