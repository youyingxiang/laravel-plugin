<?php

return [
    'name' => 'Plugin3'
];
